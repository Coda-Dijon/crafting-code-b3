type Country = 'France' | 'Germany' | 'Poland' | 'Norway';
type EngineType = 'thermal' | 'electric' | 'hybrid';

const calculateCo2ForBikeAndWalk = (_command: CalculateImpact): number => 0;

const co2ByKmForEngine: Record<Exclude<EngineType, 'electric'>, number> = {
    thermal: 0.192,
    hybrid: 0.098
};

const defaultElectricEmissionForCar = 0.04;
const co2EmissionForElectricCarByCountry: Record<Country, number> = {
    France: 0.012,
    Germany: 0.045,
    Poland: 0.078,
    Norway: defaultElectricEmissionForCar
};

const calculateCo2ForCar = (command: CalculateImpact): number => {
    function factorForElectricCar(country: Country) {
        return co2EmissionForElectricCarByCountry[country] ?? defaultElectricEmissionForCar;
    }

    const factor = command.engineType === 'electric' ?
        factorForElectricCar(command.country)
        : co2ByKmForEngine[command.engineType];

    const base = command.distance * factor;

    return command.numberOfPassengers > 0
        ? base / command.numberOfPassengers
        : base;
};

const co2EmissionForTrainByCountry: Record<Country, number> = {
    France: 0.0032,
    Germany: 0.032,
    Poland: 0.069,
    Norway: 0.001
};

const defaultCo2EmissionForTrain = 0.041;

const calculateCo2ForTrain = (command: CalculateImpact): number => {
    function factorFor(country: Country) {
        return co2EmissionForTrainByCountry[country] ?? defaultCo2EmissionForTrain;
    }

    return command.distance * factorFor(command.country);
};

const calculateCo2ForBus = (command: CalculateImpact) => {
    return command.distance * 0.104;
}

const calculationStrategies: Record<TransportWay, (c: CalculateImpact) => number> = {
    bike: calculateCo2ForBikeAndWalk,
    walk: calculateCo2ForBikeAndWalk,
    car: calculateCo2ForCar,
    train: calculateCo2ForTrain,
    bus: calculateCo2ForBus,
};

export enum Impact {
    GREEN = 'GREEN',
    ORANGE = 'ORANGE',
    RED = 'RED',
}

const impactRanges: Record<Impact, { min: number; max: number | null }> = {
    [Impact.GREEN]: {min: 0, max: 5},
    [Impact.ORANGE]: {min: 5, max: 15},
    [Impact.RED]: {min: 15, max: null}
};


export const labelFor = (co2: number): Impact => {
    function co2InRange(min: number, max: number | null): boolean {
        return co2 >= min && (max === null || co2 < max);
    }

    return Object
        .entries(impactRanges)
        .find(([_, {min, max}]) => co2InRange(min, max))[0] as Impact;
};

export const calculateCo2For = function (command: CalculateImpact) {
    return calculationStrategies[command.transportWay](command);
};
