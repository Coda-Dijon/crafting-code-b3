type TransportWay = 'bike' | 'walk' | 'car' | 'train' | 'bus';
type EngineType = 'thermal' | 'electric' | 'hybrid';
type Country = 'France' | 'Germany' | 'Poland' | 'Norway';

type CalculateImpact = {
    distance: number,
    transportWay: TransportWay,
    engineType: EngineType | undefined,
    numberOfPassengers: number | undefined,
    country: Country
}