import {calculateCo2For, Impact, labelFor} from "./calculator/co2CalculatorStrategy";

export type calculateImpactResult = { co2: number, label: Impact }

class CalculateImpactUseCase {
    calculate(distance: any,
              transportWay: any,
              engineType: any,
              numberOfPassengers: any,
              country: any): calculateImpactResult {
        let co2 = calculateCo2For({
            distance,
            transportWay: transportWay,
            engineType,
            numberOfPassengers,
            country
        });
        
        return {co2: co2, label: labelFor(co2)};
    }
}

export default new CalculateImpactUseCase();
